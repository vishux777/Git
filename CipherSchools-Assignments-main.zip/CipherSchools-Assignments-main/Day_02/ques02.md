### Question-02

Write a C++ program that takes an integer score (0-100) as input from the user and prints the corresponding grade using if-else-if statements.

Grade Criteria:

1. A: 90-100
2. B: 80-89
3. C: 70-79
4. D: 60-69
5. F: 0-59

**Sample Input:**

```
Enter the score: 85
```

**Sample Output:**

```
Grade: B
```
