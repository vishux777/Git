### Question-03

Write a C++ program that takes an integer as input from the user and prints the corresponding month of the year using a switch case statement. Assume 1 = January, 2 = February, ..., 12 = December.

If integer is not from 1 to 12 then print invalid.

**Sample Input:**

```
Enter a number : 5
```

**Sample Output:**

```
The month is: May"
```
