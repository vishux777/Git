### Question-01

Write a C++ program that takes two strings as input from the user and concatenates them. Then, output the concatenated string.

**Sample Input:**

```
Enter the first string: This is my first string
Enter the second string: This is my second string
```

**Sample Output:**

```
Concatenated string: This is my first stringThis is my second string
```
